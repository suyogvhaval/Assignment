﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebServices
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        public WebService1()
        {
                //Uncomment the following line if using designed components 
            //InitializeComponent(); 
        }
        [WebMethod]
        public String insertEmpDetails(String name, int Salary, String Depatment, String Designation)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-001\SQLEXPRESS;Initial Catalog=myassignments;User ID=sa;Password=Pa$$w0rd");
            SqlCommand cmd = new SqlCommand("insert into EmployeeDetails values('" + name + "','" + Salary + "','" + Depatment + "','" + Designation + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return "Inserted successfully...";
        }



        [WebMethod]
        public String deleteEmployee(String name)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-001\SQLEXPRESS;Initial Catalog=myassignments;User ID=sa;Password=Pa$$w0rd");
            SqlCommand cmd = new SqlCommand("delete from EmployeeDetails where EmployeeName='" + name + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return "Deleted successfully...";
        }



        [WebMethod]
        public String UpdateEmployee(String name, int salary)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-001\SQLEXPRESS;Initial Catalog=myassignments;User ID=sa;Password=Pa$$w0rd");
            SqlCommand cmd = new SqlCommand("update EmployeeDetails set Salary=" + salary + " where EmployeeName='" + name + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return "Updated successfully...";
        }



        [WebMethod]
        public String ShowEmployee()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-001\SQLEXPRESS;Initial Catalog=myassignments;User ID=sa;Password=Pa$$w0rd");
            SqlCommand cmd = new SqlCommand("select * from EmployeeDetails", con);
            con.Open();
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            string str = ds.GetXml();
            return str;
        }




    }
}
