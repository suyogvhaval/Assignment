﻿using System;


namespace WebServices
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        WebService1 w;
        protected void Page_Load(object sender, EventArgs e)
        {
            w = new WebService1();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string str = w.insertEmpDetails(TextBox1.Text, Convert.ToInt32(TextBox2.Text), TextBox3.Text, TextBox4.Text);
            Label1.Text = str;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string str = w.UpdateEmployee(TextBox1.Text, Convert.ToInt32(TextBox2.Text));
            Label1.Text = str;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string str = w.deleteEmployee(TextBox1.Text);
            Label1.Text = str;
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            string str = w.ShowEmployee();
            Label1.Text = str;
        }
    }
}